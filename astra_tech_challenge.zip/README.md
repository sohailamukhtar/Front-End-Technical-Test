# ASTRA TECH Front-End Developer Technical Challenge

This repository contains 3 technical tasks:

## 📄 Task 1: Responsive Landing Page
- Pure HTML & CSS
- `task1-landing-page/index.html`

## ✅ Task 2: Vanilla JavaScript To-Do App
- Uses localStorage to save tasks
- `task2-todo-app/index.html`

## 🔁 Task 3: React App Fetching API Data
- Instructions to build React app included in `task3-react-api/README.md`

---

### Deployment
You can deploy each folder using GitHub Pages, Netlify, or Vercel.

Good luck!
