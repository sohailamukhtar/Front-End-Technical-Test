const listEl = document.getElementById('list');
let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

function saveTasks() {
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

function renderTasks() {
  listEl.innerHTML = '';
  tasks.forEach((task, i) => {
    const li = document.createElement('li');
    li.innerHTML = `
      <span class="${task.completed ? 'completed' : ''}" onclick="toggleTask(${i})">${task.text}</span>
      <button onclick="deleteTask(${i})">X</button>
    `;
    listEl.appendChild(li);
  });
}

function addTask() {
  const taskInput = document.getElementById('task');
  if (taskInput.value.trim() === '') return;
  tasks.push({ text: taskInput.value.trim(), completed: false });
  taskInput.value = '';
  saveTasks();
  renderTasks();
}

function toggleTask(index) {
  tasks[index].completed = !tasks[index].completed;
  saveTasks();
  renderTasks();
}

function deleteTask(index) {
  tasks.splice(index, 1);
  saveTasks();
  renderTasks();
}

renderTasks();
